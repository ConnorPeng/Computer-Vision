# PS 6: Scene Recognition with Deep Learning
